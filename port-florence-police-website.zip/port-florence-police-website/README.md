# Port of Florence Police Department website

This folder contains a static website ready for GitHub Pages.

Included pages: Home, About PFPD, Services, Divisions, News & Alerts, and Contact.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload everything in this folder to the repository root.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

GitHub will provide the public website URL after deployment finishes.

## Edit through GitHub

Open any `.html` file in the repository and click the pencil icon to edit its text. `index.html` is the homepage, `site-pages.css` controls the interior-page design, and the PNG files are the seal and social preview. Commit the change when finished; GitHub Pages will update automatically.

The site represents a fictional police department in the fictional State of Ventura.
